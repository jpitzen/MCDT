TRUNCATE TABLE pfuser.ZLAV3MigVaultItem

