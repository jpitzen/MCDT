DROP SEQUENCE pfuser.ProfileTransport_sequence
DROP TABLE pfuser.ProfileTransport
DROP TABLE pfuser.MsgTransportConfirmation
DROP TABLE pfuser.MessageTransport
