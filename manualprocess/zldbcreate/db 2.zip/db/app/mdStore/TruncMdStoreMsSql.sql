TRUNCATE TABLE pfuser.MetaDataStoreItem
