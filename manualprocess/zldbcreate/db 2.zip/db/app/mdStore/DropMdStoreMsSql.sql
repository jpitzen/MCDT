DROP SEQUENCE pfuser.MetaDataStoreItem_sequence
DROP TABLE pfuser.MetaDataStoreItem
